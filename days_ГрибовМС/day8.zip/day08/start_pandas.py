import pandas

print("Pandas подключена")
print(pandas.__version__)
