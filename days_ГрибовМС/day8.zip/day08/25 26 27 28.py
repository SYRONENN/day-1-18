import pandas as pd

data = {"Имя": ["Анна", "Иван"],"Баллы": [80, 90]}

df = pd.DataFrame(data)
print(df)
print(df["Баллы"])
print(df["Имя"])
result = df[df["Баллы"] == 80]
print(result)

result = df[(df["Баллы"] >= 70) & (df["Баллы"] <= 90)]
print(result)