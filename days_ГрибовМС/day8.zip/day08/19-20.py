import pandas as pd

d = pd.DataFrame({"Имя": ["Анна", "Иван", "Мария"],"Баллы": [85, 65, 90]})

print(d["Баллы"].sum())
print(d["Баллы"].mean())
print(d["Баллы"].min())
print(d["Баллы"].max())
print(d["Баллы"].count())