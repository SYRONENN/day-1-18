import pandas as pd

d = pd.DataFrame({"Имя": ["Анна", "Иван", "Мария"],"Баллы": [85, 65, 90]})
print(d)
d["Группа"] = ["1ИИ-1", "1ИИ-2", "1ИИ-1"]
print(d)
print(d.shape)
print(d.columns)
print(d.index)