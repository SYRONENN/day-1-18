import pandas as pd

d = pd.DataFrame({"Имя": ["Анна", "Иван", "Мария"],"Баллы": [85, 65, 90],"Группа": ["1ИИ-1", "1ИИ-2", "1ИИ-1"]})
print(d.loc[0])
print(d.iloc[1])
print(d.loc[0, "Имя"])
print(d.iloc[0:2])