import pandas as pd

d = pd.DataFrame({"Имя": ["Анна", "Иван", "Мария"],"Баллы": [85, 65, 90]})
print(d.head())
print(d.tail())
d.info()
print(d.describe())