import pandas as pd

df = pd.DataFrame({"A": [1, 2, 3]})
print(df["A"].sum())

df = pd.DataFrame({"A": [10, 20, 30]})
print(df["A"].mean())

df = pd.DataFrame({"Имя": ["А", "Б"], "Баллы": [70, 90]})
print(df[df["Баллы"] >= 80])

df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
print(df.shape)

df = pd.DataFrame({"A": [5, 6, 7]})
print(df.iloc[1])