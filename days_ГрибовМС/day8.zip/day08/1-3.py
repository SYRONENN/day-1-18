import pandas as pd

s = pd.Series([75, 90, 65, 88, 70])
print(s)
print(s.iloc[0])
print(s.iloc[2])
s = pd.Series([18, 20, 17], index=["Пн", "Вт", "Ср"])
print(s)
print(s["Вт"])