with open("technologies.txt", "r", encoding="utf-8") as f:
    for line in f:
        print(line.strip())