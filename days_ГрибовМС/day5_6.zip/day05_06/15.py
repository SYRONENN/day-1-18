with open("hello.txt", "a", encoding="utf-8") as f:
    f.write("строка 6\n")
    f.write("строка 7\n")

with open("hello.txt", "r", encoding="utf-8") as f:
    print(f.read())