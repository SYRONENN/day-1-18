scores = [45, 78, 91, 53, 60, 39, 99, 75]
for score in scores:
    if score >= 60:
        print(score, "зачёт")
    else:
        print(score, "незачёт")