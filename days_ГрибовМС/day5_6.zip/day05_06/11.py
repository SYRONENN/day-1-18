for i in range(1, 16):
    if i == 5 or i == 10:
        continue
    print(i)