names = ["Анна", "Иван", "Олег", "Мария", "Петр", "Елена", "Ольга"]
for name in names:
    print(name)