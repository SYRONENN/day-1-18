with open("hello.txt", "w", encoding="utf-8") as f:
    f.write("Строка 1\n")
    f.write("Строка 2\n")
    f.write("Строка 3\n")
    f.write("Строка 4\n")
    f.write("Строка 5\n")