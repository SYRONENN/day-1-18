while True:
    word = input("введите слово: ")
    if word == "стоп":
        break