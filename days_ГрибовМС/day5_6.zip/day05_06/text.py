with open("notes.txt", "w", encoding="utf-8") as file:
    file.write("Первая строка\n")
    file.write("Вторая строка\n")
with open("notes.txt", "r", encoding="utf-8") as file:
    print(file.read())