scores = [45, 78, 91, 53, 60, 39, 99, 75, 82, 95]

with open("scores.txt", "w", encoding="utf-8") as f:
    for score in scores:
        f.write(str(score) + "\n")