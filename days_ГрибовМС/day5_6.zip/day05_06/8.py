tech = ["Python", "Java", "VSCDE", "IT", "Linux", "sql"]
user = input("Введите название технологии: ")
if user in tech:
    print("Есть в списке")
else:
    print("Нет в списке")