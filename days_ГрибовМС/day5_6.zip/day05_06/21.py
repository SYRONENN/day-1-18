nums = []
with open("scores.txt", "r", encoding="utf-8") as f:
    for line in f:
        number = int(line.strip())
        nums.append(number)
a = 0
b = 0
for score in nums:
    if score >= 60:
        a = a + 1
    else:
        b = b + 1
with open("report.txt", "w", encoding="utf-8") as f:
    f.write("Количество зачётов: " + str(a) + "\n")
    f.write("Количество незачётов: " + str(a) + "\n")