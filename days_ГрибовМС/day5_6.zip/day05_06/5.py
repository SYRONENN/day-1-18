scores = [45, 78, 91, 53, 60, 39, 88, 75]
a = 0
b = 0
for score in scores:
    if score >= 60:
        a = a + 1
    else:
        b = b + 1
print("Зачётов:", a)
print("Незачётов:", b)