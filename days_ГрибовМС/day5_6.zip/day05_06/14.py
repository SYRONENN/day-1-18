with open("hello.txt", "r", encoding="utf-8") as f:
    text = f.read()
    print(text)