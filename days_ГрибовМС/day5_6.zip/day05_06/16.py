name = input("имя: ")
name2 = input("фамилия: ")
group = input("группа: ")
spec = input("специальность: ")

with open("student.txt", "w", encoding="utf-8") as f:
    f.write(name + "\n")
    f.write(name2 + "\n")
    f.write(group + "\n")
    f.write(spec + "\n")
