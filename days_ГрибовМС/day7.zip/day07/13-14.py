import numpy as np
data = np.array([[1, 2], [3, 4]])
print(data + 10)
print(data * 2)