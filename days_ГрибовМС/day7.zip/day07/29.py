import numpy as np

data = np.array([
    [40, 55, 65, 75, 85]
])
print(np.mean(data, axis=1))
print(np.mean(data, axis=0))
print(np.min(data))
print(np.max(data))