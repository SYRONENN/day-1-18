import numpy as np

numbers = np.arange(1, 13)
matrix_3_4 = numbers.reshape(3, 4)
print(matrix_3_4)
matrix_2_6 = numbers.reshape(2, 6)
print(matrix_2_6)