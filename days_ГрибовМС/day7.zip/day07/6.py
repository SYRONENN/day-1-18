import numpy as np
data = np.array([[10, 20, 30], [40, 50, 60]])
data[1] = [7, 8, 9]
print(data)