import numpy as np

data = np.array([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]])
print(data[0:2])
print(data[:, 1:3])
print(data[1:3, 1:3])
