import numpy as np

data = np.array([
    [20, 30, 40, 50]
])
print(np.sum(data))
print(np.sum(data, axis=1))
print(np.sum(data, axis=0))
print(np.mean(data))