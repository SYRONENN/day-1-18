import numpy as np

data = np.array([
    [10, 12, 15, 13, 9]
])

print(np.mean(data, axis=1))
print(np.mean(data, axis=0))

avg = np.mean(data)
print(data[data > avg])