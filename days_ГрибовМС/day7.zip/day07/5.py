import numpy as np

data = np.array([[10, 20, 30, 40], [50, 60, 70, 80], [90, 91, 92, 93]])
data[1, 1] = 999
print(data)