import numpy as np

data = np.array([[10, 20, 30, 40], [50, 60, 70, 80], [90, 91, 92, 93]])
print(data[0, 0])
print(data[0, -1])
print(data[-1, 0])
print(data[-1, -1])