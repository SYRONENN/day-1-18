import numpy as np

data = np.array([[40, 50, 60], [70, 80, 90]])
print(data[data >= 60])
avg = np.mean(data)
print(data[data < avg])
print(data[(data >= 50) & (data <= 80)])