import numpy as np

data = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])

print(np.sum(data))
print(np.mean(data))
print(np.min(data))
print(np.max(data))